package com.biggerminds.calculator_alex;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    Button n1, n2, n3, n4, n5, n6, n7, n8, n9, n0,
            dot, del, clear, add, minus, multiply, divide, equals;
    TextView input1, input2, signs;
    String sign, value1, value2;
    Double num1, num2, result;
    boolean hasDot, isResult, hasSign, addition, subtraction, division, multiplication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input1 = findViewById(R.id.input);
        input2 = findViewById(R.id.input2);
        signs = findViewById(R.id.sign);
        hasDot = false;
        hasSign = false;
        isResult = false;



        n0 = findViewById(R.id.n0);
        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        n3 = findViewById(R.id.n3);
        n4 = findViewById(R.id.n4);
        n5 = findViewById(R.id.n5);
        n6 = findViewById(R.id.n6);
        n7 = findViewById(R.id.n7);
        n8 = findViewById(R.id.n8);
        n9 = findViewById(R.id.n9);
        dot = findViewById(R.id.dot);
        del = findViewById(R.id.del);
        clear = findViewById(R.id.clear);
        add = findViewById(R.id.add);
        minus = findViewById(R.id.minus);
        divide = findViewById(R.id.divide);
        multiply = findViewById(R.id.multiply);
        equals = findViewById(R.id.equals);
        signs = findViewById(R.id.sign);

        n0.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "0");
                } else if (isResult){
                    input1.setText("0");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "0");
                    input2.setText("");
                }
            }
        });

        n1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "1");
                } else if (isResult){
                    input1.setText("1");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "1");
                    input2.setText("");
                }
            }
        });

        n2.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "2");
                } else if (isResult){
                    input1.setText("2");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "2");
                    input2.setText("");
                }
            }
        });
        n3.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "3");
                } else if (isResult){
                    input1.setText("3");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "3");
                    input2.setText("");
                }
            }
        });
        n4.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "4");
                } else if (isResult){
                    input1.setText("4");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "4");
                    input2.setText("");
                }
            }
        });
        n5.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "5");
                } else if (isResult){
                    input1.setText("5");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "5");
                    input2.setText("");
                }
            }
        });
        n6.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "6");

                } else if (isResult){
                    input1.setText("6");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "6");
                    input2.setText("");
                }
            }

        });
        n7.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "7");
                } else if (isResult){
                    input1.setText("7");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "7");
                    input2.setText("");
                }
            }
        });
        n8.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "8");
                } else if (isResult){
                    input1.setText("8");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "8");
                    input2.setText("");
                }
            }
        });
        n9.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (hasSign) {
                    input1.setText(input1.getText() + "9");
                } else if (isResult){
                    input1.setText("9");
                    input2.setText("");
                    isResult=false;
                }
                else {
                    input1.setText(input1.getText().toString() + "9");
                    input2.setText("");
                }
            }
        });
        dot.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (!hasDot) {
                    if (input1.getText().equals("")) {
                        input1.setText("0.");
                    } else {
                        input1.setText(input1.getText() + ".");
                        input2.setText(input2.getText() + ".");
                    }
                    hasDot = true;
                }

            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                sign = "+";
                if (!hasSign) {
                    value1 = input1.getText().toString();
                    input2.setText(value1 + "+");
                    input1.setText(null);
                    signs.setText("+");
                }
                else { input1.setText(input1.getText().toString());
                    input2.setText(input2.getText().toString());
                    signs.setText(signs.getText());
                }
                hasSign = true;
                hasDot = false;
                addition=true;
            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                sign = "-";
                if (!hasSign) {
                    value1 = input1.getText().toString();
                    input2.setText(value1 + "-");
                    input1.setText(null);
                    signs.setText("-");
                }
                else { input1.setText(input1.getText().toString());
                    input2.setText(input2.getText().toString());
                    signs.setText(signs.getText());
                }
                hasSign = true;
                hasDot = false;
                subtraction=true;
            }
        });
        divide.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                sign = "/";
                if (!hasSign) {
                    value1 = input1.getText().toString();
                    input2.setText(value1 + "/");
                    input1.setText(null);
                    signs.setText("/");
                }
                else { input1.setText(input1.getText().toString());
                    input2.setText(input2.getText().toString());
                    signs.setText(signs.getText());
                }
                hasSign = true;
                hasDot = false;
                division=true;
            }

        });
        multiply.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                sign = "*";
                if (!hasSign) {
                    value1 = input1.getText().toString();
                    input2.setText(value1 + "*");
                    input1.setText(null);
                    signs.setText("*");
                    multiplication=true;
                }
                else { input1.setText(input1.getText().toString());
                    input2.setText(input2.getText().toString());
                    multiplication = false;
                }
                hasSign = true;
                hasDot = false;
            }

        });

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (input1.getText().equals("")) {
                    input1.setText(null);
                    input2.setText(null);
                    hasSign = false;
                    sign = null;
                } else if (isResult) {
                    input1.setText("");
                    input2.setText("");
                } else {
                    int len = input1.getText().length();
                    String s = input1.getText().toString();
                    if (s.charAt(len - 1) == '.') {
                        hasDot = false;
                        input1.setText(input1.getText().subSequence(0, input1.getText().length() - 1));

                    } else {
                        input1.setText(input1.getText().subSequence(0, input1.getText().length() - 1));
                    }
                }
            }

        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input1.setText(null);
                input2.setText(null);
                signs.setText(null);
                value2 = null;
                value1 = null;
                sign = null;
                hasSign = false;
                hasDot = false;
            }
        });

        equals.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (input1.getText().equals("")) {
                    signs.setText("Enter value");
                } else if (sign != null) {
                    value2 = input1.getText().toString();
                    num1 = Double.parseDouble(value1);
                    num2 = Double.parseDouble(value2);
                    input1.setText(null);
                    input2.setText(null);
                    hasSign=false;

                    switch (sign) {
                        default:
                            break;

                        case "+":
                            result = num1 + num2;
                            input2.setText(value1 + "+" + num2);
                            input1.setText(result + "");
                            sign = null;
                            signs.setText(null);
                            isResult = true;
                            break;
                        case "-":
                            result = num1 - num2;
                            input2.setText(value1 + "-" + num2);
                            input1.setText(result + "");
                            sign = null;
                            signs.setText(null);
                            isResult = true;
                            break;
                        case "*":
                            result = num1 * num2;
                            input2.setText(value1 + "*" + num2);
                            input1.setText(result + "");
                            sign = null;
                            signs.setText(null);
                            isResult = true;
                            break;
                        case "/":
                            result = num1 / num2;
                            input2.setText(value1 + "/" + num2);
                            input1.setText(result + "");
                            sign = null;
                            signs.setText(null);
                            isResult = true;
                            break;
                    }
                }
            }
        });


    }


}
